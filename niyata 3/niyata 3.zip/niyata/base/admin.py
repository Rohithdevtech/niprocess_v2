from django.contrib import admin
from .models import CustomUser, Profile,Department,Position,AspiceSdlcDoc,ProcessGroup,ProcessArea,Role

# Register your models here.

admin.site.register(CustomUser)
admin.site.register(Profile)
admin.site.register(Department)
admin.site.register(AspiceSdlcDoc)
admin.site.register(Position)
admin.site.register(ProcessGroup)
admin.site.register(ProcessArea)
admin.site.register(Role)


