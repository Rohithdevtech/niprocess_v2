from django.forms import ModelForm
from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, Profile, Department, AspiceSdlcDoc, Position, ProcessGroup, ProcessArea, Role
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import authenticate
from django.contrib.auth.forms import PasswordChangeForm
# from django.contrib.auth.models import User


class CustomPasswordChangeForm(PasswordChangeForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['old_password'].widget = forms.PasswordInput(
            attrs={'class': 'form-control'})
        self.fields['new_password1'].widget = forms.PasswordInput(
            attrs={'class': 'form-control'})
        self.fields['new_password2'].widget = forms.PasswordInput(
            attrs={'class': 'form-control'})

    def __init__(self, *args, **kwargs):
        super(CustomPasswordChangeForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})


class EmployeeCreationForm(UserCreationForm):
    class Meta:
        model = CustomUser
        fields = ['name', 'username', 'email', 'phone_number', 'employee_id',
                  'position', 'department', 'user_type', 'password1', 'password2']

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if not email.endswith('@niyatainfotech.com'):
            raise forms.ValidationError(
                'Only email addresses ending with @niyatainfotech.com are allowed.')
        return email

    def save(self, commit=True):
        user = super(EmployeeCreationForm, self).save(commit=False)
        if commit:
            user.save()
            # Additional employee-specific fields can be assigned here if necessary
        return user

    def __init__(self, *args, **kwargs):
        super(EmployeeCreationForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})


class EmployeeUpdateForm(ModelForm):
    class Meta:
        model = CustomUser
        fields = ['name', 'username', 'email', 'user_type',
                  'employee_id', 'department', 'position']
        # fields = '__all__'  # You can specify the fields you want to include in the form

    def __init__(self, *args, **kwargs):
        super(EmployeeUpdateForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})


class ProfileForm(ModelForm):
    class Meta:
        model = Profile
        fields = ['profile_image', 'name', 'skills', 'phone', 'date_of_birth', 'address',
                  'pan', 'aadhar', 'uan', 'marital_status', 'blood_group', 'location']

        # 'username', 'phone_number', 'employee_id', 'department', 'position',

    def __init__(self, *args, **kwargs):
        super(ProfileForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})


class DepartmentForm(ModelForm):
    class Meta:
        model = Department
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(DepartmentForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})


class PositionForm(ModelForm):
    class Meta:
        model = Position
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(PositionForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})


class AspiceSdlcDocForm(ModelForm):
    class Meta:
        model = AspiceSdlcDoc
        exclude = ['created_by', 'updated_by', 'admin_manager']
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(AspiceSdlcDocForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})


# Aspice Master

class ProcessGroupForm(ModelForm):
    class Meta:
        model = ProcessGroup
        exclude = ['created_by', 'updated_by', 'admin_manager']
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(ProcessGroupForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})


class ProcessAreaForm(ModelForm):
    class Meta:
        model = ProcessArea
        exclude = ['created_by', 'updated_by', 'admin_manager']
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(ProcessAreaForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})


class RoleForm(ModelForm):
    class Meta:
        model = Role
        exclude = ['created_by', 'updated_by', 'admin_manager']
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(RoleForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})

# Searching Functionality


class SearchForm(forms.Form):
    query = forms.CharField(label='Search')
