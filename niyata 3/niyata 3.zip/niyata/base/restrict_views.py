# from django.contrib.auth.decorators import login_required
# from django.shortcuts import render
# from .decorators import hr_user_required, admin_user_required, superuser_required

# @login_required
# @hr_user_required
# def hr_dashboard(request):
#     # Only HR users can access this view
#     return render(request, 'hr_dashboard.html')

# @login_required
# @admin_user_required
# def admin_dashboard(request):
#     # Only Admin users can access this view
#     return render(request, 'admin_dashboard.html')

# @login_required
# @superuser_required
# def superuser_dashboard(request):
#     # Only Super User users can access this view
#     return render(request, 'superuser_dashboard.html')

# @login_required
# @admin_user_required
# def admin_dashboard(request):
#     # Only Admin users can access this view
#     return render(request, 'admin_dashboard.html')

# @login_required
# @superuser_required
# def superuser_dashboard(request):
#     # Only Super User users can access this view
#     return render(request, 'superuser_dashboard.html')


#-------------------------Second Method of Locking-----------------------------

# from django.contrib.auth.decorators import login_required, user_passes_test

# def is_admin_user(user):
#     return user.is_superuser or user.user_type == 'admin'

# @login_required
# @user_passes_test(is_admin_user)
# def admin_view(request):
#     # This view can only be accessed by superusers or users with "admin" user_type
#     pass


# from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
# from django.shortcuts import redirect

# class AdminRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
#     def test_func(self):
#         return self.request.user.is_superuser or self.request.user.user_type == 'admin'

#     def handle_no_permission(self):
#         return redirect('login')  # Or any other appropriate redirect URL

# class AdminView(AdminRequiredMixin, View):
#     def dispatch(self, request, *args, **kwargs):
#         return super().dispatch(request, *args, **kwargs)  # Call parent's dispatch

#     def get(self, request, *args, **kwargs):
#         # Admin view logic
#         pass


#-------------------------Third Method of Locking-----------------------------


# from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
# from django.shortcuts import redirect

# class AdminRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
#     def test_func(self):
#         return self.request.user.is_superuser or self.request.user.user_type == 'admin'

#     def handle_no_permission(self):
#         return redirect('login')  # Or any other appropriate redirect URL

# class HRRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
#     def test_func(self):
#         return self.request.user.user_type == 'hr'

#     def handle_no_permission(self):
#         return redirect('login')

# class NormalUserRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
#     def test_func(self):
#         return self.request.user.user_type == 'normal'

#     def handle_no_permission(self):
#         return redirect('login')

# class AdminView(AdminRequiredMixin, View):
#     def dispatch(self, request, *args, **kwargs):
#         return super().dispatch(request, *args, **kwargs)

#     def get(self, request, *args, **kwargs):
#         # Admin view logic
#         pass

# class HRView(HRRequiredMixin, View):
#     def dispatch(self, request, *args, **kwargs):
#         return super().dispatch(request, *args, **kwargs)

#     def get(self, request, *args, **kwargs):
#         # HR view logic
#         pass

# class NormalUserView(NormalUserRequiredMixin, View):
#     def dispatch(self, request, *args, **kwargs):
#         return super().dispatch(request, *args, **kwargs)

#     def get(self, request, *args, **kwargs):
#         # Normal user view logic
#         pass

# {% if request.user.is_superuser or request.user.user_type == 'admin' %}
#   <h1>Admin View Content</h1>
#   {% else %}
#   <p>You are not authorized to access this view.</p>
# {% endif %}




    #  employee = form.save(commit=False)
    #         employee.created_at = timezone.now() 


# employee = form.save(commit=False)
#             employee.updated_at = timezone.now()  # Set updated_at


#  role = form.save(commit=False)
#             role.created_by = request.user 


#     role = form.save(commit=False)
#             role.updated_by = request.user 