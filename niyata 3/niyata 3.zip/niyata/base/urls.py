from django.urls import path
from . import views


urlpatterns = [
    # Base URls
    path('', views.home, name='home'),

    # Auth URls
    path('register/', views.registerUser, name='register'),
    path('login/', views.loginUser, name='login'),
    path('logout/', views.logoutUser, name='logout'),
    path('change-password/', views.change_password, name='change-password'),
    path('password-change-success/', views.password_change_success, name='password-change-success'),


    # Profile URls
    path('user-profile/', views.user_profile, name='user-profile'),
    path('update-profile/', views.update_profile, name='update-profile'),
    path('profile-updated/', views.profile_updated, name='profile-updated'),


    # Normal User Access URls
    path('aspice-docs/', views.aspiceDocs, name='aspice-docs'),
    path('aspice-table/', views.aspicetable, name='aspice-table'),
    path('vm-document-list/', views.vm_document_list, name='vm-document-list'),


    path('documents/', views.v_document_list, name='document_list'),
    path('documents/<int:process_group_id>/',
         views.v_document_list, name='document_list_filtered'),


    # Aspice Docs Access URls
    path('admin-access/', views.admin_access, name='admin-access'),
    path('aspice-master/', views.aspice_master, name='aspice-master'),


    # ASPICE-SDLC-CRUD Operations URls
    path('sdlc-master-document-list/', views.sdlc_master_document_list,
         name='sdlc-master-document-list'),
    path('sdlc-master-document-detail/<int:pk>/',
         views.sdlc_master_document_detail, name='sdlc-master-document-detail'),
    path('sdlc-master-document-create/', views.sdlc_master_document_create,
         name='sdlc-master-document-create'),
    path('sdlc-master-document-update/<int:pk>/',
         views.sdlc_master_document_update, name='sdlc-master-document-update'),
    path('sdlc-master-document-delete/<int:pk>/delete/',
         views.sdlc_master_document_delete, name='sdlc-master-document-delete'),


    # ASPICE Master-------------------Process Group-------------------
    path('master-process-group-form/', views.master_process_group_form,
         name='master-process-group-form'),
    path('master-process-group-list/', views.master_process_group_list,
         name='master-process-group-list'),
    path('master-process-group-detail/<int:pk>/',
         views.master_process_group_detail, name='master-process-group-detail'),
    path('master-process-group-update/<int:pk>/update/',
         views.master_process_group_update, name='master-process-group-update'),
    path('master-process-group-delete/<int:pk>/delete/',
         views.master_process_group_delete, name='master-process-group-delete'),

    # ASPICE Master-------------------Process Group Area-------------------
    path('master-process-area-form/', views.master_process_area_form,
         name='master-process-area-form'),
    path('master-process-area-list/', views.master_process_area_list,
         name='master-process-area-list'),
    path('master-process-area-detail/<int:pk>/',
         views.master_process_area_detail, name='master-process-area-detail'),
    path('master-process-area-update/<int:pk>/update/',
         views.master_process_area_update, name='master-process-area-update'),
    path('master-process-area-delete/<int:pk>/delete/',
         views.master_process_area_delete, name='master-process-area-delete'),


    # ASPICE Master--------------------Role-------------------------------------
    path('master-role-form/', views.master_role_form, name='master-role-form'),
    path('master-role-list/', views.master_role_list, name='master-role-list'),
    path('master-role-detail/<int:pk>/',
         views.master_role_detail, name='master-role-detail'),
    path('master-role-update/<int:pk>/update/',
         views.master_role_update, name='master-role-update'),
    path('master-role-delete/<int:pk>/delete/',
         views.master_role_delete, name='master-role-delete'),


    # HR Access Processc URls
    # Users CRUD Operations
    path('create-employee/', views.create_employee, name='create-employee'),
    path('list-all-employees/', views.list_all_employees,
         name='list-all-employees'),
    path('employee/<int:pk>/edit/', views.edit_employee, name='edit-employee'),
    path('employee/<int:pk>/delete/',
         views.delete_employee, name='delete-employee'),

    # Searching Functionality

    path('try-model/', views.try_model, name='try-model'),
]
