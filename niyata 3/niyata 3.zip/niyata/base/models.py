from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.validators import URLValidator
from django.core.validators import RegexValidator, EmailValidator
import secrets
from django.utils import timezone
import os


class CustomUser(AbstractUser):
    name = models.CharField(max_length=200, null=True)
    email = models.EmailField(unique=True, null=True)
    USER_TYPE_CHOICES = (
        ('normal', 'Normal User'),
        ('hr', 'HR User'),
        ('admin', 'Admin User'),
        ('superuser', 'Super User'),
    )
    user_type = models.CharField(
        max_length=20, choices=USER_TYPE_CHOICES, default='normal')
    phone_number = models.CharField(max_length=15, blank=True, null=True, validators=[
                                    RegexValidator(regex='^\+?1?\d{9,15}$', message='Enter a valid phone number')])
    # otp = models.CharField(max_length=6, blank=True, null=True, validators=[
    #                        RegexValidator(regex='^\d{6}$', message='OTP must be 6 digits')])

    # Employee-specific fields
    department = models.ForeignKey(
        'Department', on_delete=models.SET_NULL, null=True, blank=True)
    position = models.ForeignKey(
        'Position', on_delete=models.SET_NULL, null=True, blank=True)
    employee_id = models.CharField(
        max_length=50, unique=True, null=True, blank=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']  # 'name' is required, so it should be in REQUIRED_FIELDS

    # def generate_otp(self):
    #     # Generate a 6-digit OTP
    #     # Using secrets module for cryptographically secure random number generation
    #     return secrets.token_hex(3)[:6]

    # def save(self, *args, **kwargs):
    #     if not self.otp:
    #         self.otp = self.generate_otp()
    #     super().save(*args, **kwargs)


class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        CustomUser, on_delete=models.SET_NULL, null=True, related_name='%(class)s_created_by')
    updated_by = models.ForeignKey(
        CustomUser, on_delete=models.SET_NULL, null=True, related_name='%(class)s_updated_by')

    def save(self, *args, **kwargs):
        if not self.id:
            self.created_at = timezone.now()
        self.updated_at = timezone.now()
        return super(BaseModel, self).save(*args, **kwargs)

    class Meta:
        abstract = True


class Department(BaseModel):
    name = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.name


class Position(BaseModel):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Profile(BaseModel):
    user = models.OneToOneField(
        CustomUser, on_delete=models.CASCADE, related_name='profile')
    profile_image = models.ImageField(
        upload_to='profiles/', default="profiles/user-default.png", blank=True)
    name = models.CharField(max_length=200, null=True)
    username = models.CharField(max_length=200, null=True)
    email = models.EmailField(unique=True, null=True)
    phone_number = models.CharField(max_length=15, null=True)
    phone = models.CharField(max_length=20, blank=True)
    employee_id = models.CharField(max_length=200, null=True)
    department = models.CharField(max_length=200, null=True)
    position = models.CharField(max_length=200, null=True)
    skills = models.TextField(null=True, blank=True)
    # Use DateField for proper date handling
    date_of_birth = models.DateField(null=True, blank=True)
    address = models.TextField(null=True, blank=True)
    pan = models.CharField(max_length=10)  # Standard PAN length
    # Standard Aadhar length
    aadhar = models.CharField(max_length=12, blank=True)
    uan = models.CharField(max_length=12, blank=True)  # Standard UAN length
    # marital_status = models.CharField(max_length=50, choices=[  # Predefined choices for consistency
    #     ('Single', 'Single'), ('Married', 'Married'), ('Divorced',
    #                                                    'Divorced'), ('Widowed', 'Widowed'),
    # ], blank=True)
    marital_status = models.CharField(max_length=50, choices=[  # Predefined choices for consistency
        ('Single', 'Single'), ('Married', 'Married'),
    ], blank=True)
    blood_group = models.CharField(max_length=10, choices=[  # Predefined choices for consistency
        ('A+', 'A+'), ('A-', 'A-'), ('B+', 'B+'), ('B-', 'B-'),
        ('AB+', 'AB+'), ('AB-', 'AB-'), ('O+', 'O+'), ('O-', 'O-'),
    ], blank=True)
    location = models.CharField(max_length=200, null=True, blank=True)
    social_linkedin = models.URLField(blank=True, null=True, validators=[
                                      URLValidator()])  # Validate URL format

    def __str__(self):
        return str(self.user)


# Aspice Docs Models
class ProcessGroup(BaseModel):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]

    process_group_id = models.CharField(max_length=200)
    process_group_name = models.CharField(max_length=200)
    effective_start_date = models.DateField()
    effective_end_date = models.DateField()
    status = models.CharField(max_length=200, choices=STATUS_CHOICES)

    def __str__(self):
        return self.process_group_name


class ProcessArea(BaseModel):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    process_area_id = models.CharField(max_length=200,)
    process_area_name = models.CharField(max_length=200)
    process_group = models.ForeignKey(ProcessGroup, on_delete=models.CASCADE)
    effective_start_date = models.DateField()
    effective_end_date = models.DateField()
    status = models.CharField(max_length=200, choices=STATUS_CHOICES)

    def __str__(self):
        return self.process_area_name


class Role(BaseModel):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    role_id = models.CharField(max_length=200)
    role_name = models.CharField(max_length=200)
    effective_start_date = models.DateField()
    effective_end_date = models.DateField()
    status = models.CharField(max_length=200, choices=STATUS_CHOICES)

    def __str__(self):
        return self.role_name


# def custom_upload_to(instance, filename):
#     """
#     Function to specify the upload path for files.
#     """
#     return os.path.join('uploads', filename)


class AspiceSdlcDoc(BaseModel):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    # admin_manager = models.ForeignKey(
    #     User, on_delete=models.SET_NULL, null=True, related_name='aspice_docs')  # User can be an admin
    process_group = models.ForeignKey(
        ProcessGroup, on_delete=models.CASCADE, null=True)
    process_area = models.ForeignKey(
        ProcessArea, on_delete=models.CASCADE, null=True)
    role = models.ForeignKey(Role, on_delete=models.CASCADE, null=True)
    document_name = models.CharField(max_length=200)
    status = models.CharField(max_length=200, choices=STATUS_CHOICES)
    attachment = models.FileField(upload_to='aspice_docs/')

    def __str__(self):
        return self.document_name
