from django.shortcuts import render
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .decorators import hr_user_required, admin_user_required, superuser_required
import logging
from django.db.models import Q
from .models import CustomUser, Profile, AspiceSdlcDoc, ProcessGroup, ProcessArea, Role
from .forms import EmployeeCreationForm, EmployeeUpdateForm, ProfileForm, AspiceSdlcDocForm, ProcessAreaForm, ProcessGroupForm, RoleForm, CustomPasswordChangeForm, SearchForm
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
import logging
logger = logging.getLogger(__name__)

# Create your views here.

# Base Views


@login_required(login_url='login')
def home(request):
    return render(request, 'base/home.html')

# ---------------------Auth Views----------------------


def registerUser(request):
    form = EmployeeCreationForm()

    if request.method == 'POST':
        form = EmployeeCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.username = user.username.lower()
            user.save()
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'An error occurred during registration')
    return render(request, 'base/external_register_page.html', {'form': form})


# def loginUser(request):
#     page = 'login'
#     if request.user.is_authenticated:
#         return redirect('home')

#     if request.method == "POST":
#         email = request.POST.get('email').lower()
#         password = request.POST.get('password')
#         try:
#             user = User.objects.get(email=email)
#         except:
#             messages.error(request, "User does not exist")

#         user = authenticate(request, email=email, password=password)

#         if user is not None:
#             login(request, user)
#             return redirect('home')
#         else:
#             messages.error(request, "Username OR password does not exist")

#     context = {'page': page}

#     return render(request, 'base/login.html', context)


def loginUser(request):
    page = 'login'
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == "POST":
        email = request.POST.get('email').lower()
        password = request.POST.get('password')
        try:
            user = CustomUser.objects.get(email=email)
        except CustomUser.DoesNotExist:
            messages.error(request, "User does not exist")
            logger.error("User does not exist with email: %s", email)
            # Redirect back to login page or handle as needed
            return redirect('login')

        user = authenticate(request, email=email, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, "Username OR password does not exist")
            logger.error("Incorrect username or password for email: %s", email)
            # Redirect back to login page or handle as needed
            return redirect('login')

    context = {'page': page}

    return render(request, 'base/login.html', context)


def logoutUser(request):
    logout(request)
    messages.info(request, 'User was logged out!')
    return redirect('login')


@login_required
def change_password(request):
    if request.method == 'POST':
        form = CustomPasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            # Reauthenticate user to update the session
            user = authenticate(username=user.username,
                                password=form.cleaned_data['new_password1'])
            if user is not None:
                login(request, user)
                messages.success(
                    request, 'Your password was successfully updated!')
                return redirect('password-change-success')
            else:
                messages.error(
                    request, 'Failed to update password. Please try again.')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = CustomPasswordChangeForm(request.user)
    return render(request, 'base/change_password.html', {
        'form': form
    })


def password_change_success(request):
    return render(request, 'base/password_change_success.html')

# ----------------------Profile Views----------------------


@login_required(login_url='login')
def profile_updated(request):
    return render(request, 'base/profile_updated.html')


@login_required
def user_profile(request):
    profile = Profile.objects.get(user=request.user)
    context = {'profile': profile}
    return render(request, 'base/user_profile.html', context)


@login_required(login_url='login')
def user_profile(request):
    try:
        profile = Profile.objects.get(user=request.user)
    except Profile.DoesNotExist:
        # Handle the case where the Profile does not exist
        profile = None

    context = {'profile': profile}
    return render(request, 'base/user_profile.html', context)


@login_required(login_url='login')
def update_profile(request):
    profile = request.user.profile
    form = ProfileForm(instance=profile)

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            profile_update = form.save(commit=False)
            profile_update.updated_by = request.user
            profile_update.save()

            return redirect('profile-updated')

    context = {'form': form}
    return render(request, 'base/update_profile.html', context)

# ----------------------------#Normal User Access Views-------------------


@login_required
def aspiceDocs(request):
    return render(request, 'base/v_model.html')


@login_required
def aspicetable(request):
    return render(request, 'base/aspice_table.html')


@login_required
def vm_document_list(request):
    documents = AspiceSdlcDoc.objects.filter(status='active')
    return render(request, 'base/vm_document_list.html', {'documents': documents})


@login_required
def v_document_list(request):
    all_process_groups = ProcessGroup.objects.all()
    process_group_id = request.GET.get('process_group')

    if process_group_id:
        try:
            process_group = ProcessGroup.objects.get(pk=process_group_id)
            aspice_docs = AspiceSdlcDoc.objects.filter(
                process_group=process_group)
        except ProcessGroup.DoesNotExist:
            aspice_docs = None
            process_group = None  # Handle case where process_group_id doesn't exist
    else:
        aspice_docs = AspiceSdlcDoc.objects.all()

    context = {'all_process_groups': all_process_groups,
               'aspice_docs': aspice_docs, 'process_group_id': process_group_id}
    return render(request, 'base/lm_document_list.html', context)


# -----------------Admin Access Views------------------
@login_required
@admin_user_required
def admin_access(request):
    return render(request, 'base/admin_access.html')


@login_required
@admin_user_required
def sdlc_master_document_list(request):
    documents = AspiceSdlcDoc.objects.all()
    return render(request, 'base/sdlc_master_docs_list.html', {'documents': documents})


@login_required
@admin_user_required
def sdlc_master_document_detail(request, pk):
    document = get_object_or_404(AspiceSdlcDoc, pk=pk)
    return render(request, 'base/sdlc_master_docs_detail.html', {'document': document})


@login_required
@admin_user_required
def sdlc_master_document_create(request):
    if request.method == 'POST':
        form = AspiceSdlcDocForm(request.POST, request.FILES)

        if form.is_valid():
            master_document_create = form.save(commit=False)
            master_document_create.created_by = request.user
            master_document_create.save()
            return redirect('sdlc-master-document-list')
    else:
        form = AspiceSdlcDocForm()
    return render(request, 'base/sdlc_master_docs_create.html', {'form': form})


@login_required
@admin_user_required
def sdlc_master_document_update(request, pk):
    document = get_object_or_404(AspiceSdlcDoc, pk=pk)
    if request.method == 'POST':
        form = AspiceSdlcDocForm(
            request.POST, request.FILES, instance=document)
        if form.is_valid():
            master_document_update = form.save(commit=False)
            master_document_update.updated_by = request.user
            master_document_update.save()
            return redirect('document_detail', pk=pk)
    else:
        form = AspiceSdlcDocForm(instance=document)
    return render(request, 'base/sdlc_master_docs_update.html', {'form': form})


@login_required
@admin_user_required
def sdlc_master_document_delete(request, pk):
    document = get_object_or_404(AspiceSdlcDoc, pk=pk)
    if request.method == 'POST':
        document.delete()
        return redirect('sdlc-master-document-list')
    return render(request, 'base/sdlc_master_docs_confirm_delete.html', {'document': document})


# ------------------Master CURD Views (Aspice Admin)
@login_required
@admin_user_required
def aspice_master(request):
    return render(request, 'base/aspice_master.html')

# ------------------Master CURD Views (Aspice Admin)-------------------Process Group


@login_required
@admin_user_required
def master_process_group_form(request):
    if request.method == 'POST':
        form = ProcessGroupForm(request.POST, request.FILES)

        if form.is_valid():
            process_group_form = form.save(commit=False)
            process_group_form.created_by = request.user
            process_group_form.save()
            return redirect('document_list')
    else:
        form = ProcessGroupForm()
    return render(request, 'base/master_process_group_form.html', {'form': form})


@login_required
@admin_user_required
def master_process_group_list(request):
    documents = ProcessGroup.objects.all()
    return render(request, 'base/master_process_group_list.html', {'documents': documents})


@login_required
@admin_user_required
def master_process_group_detail(request, pk):
    documents = get_object_or_404(ProcessGroup, pk=pk)
    return render(request, 'base/master_process_group_detail.html', {'documents': documents})


@login_required
@admin_user_required
def master_process_group_update(request, pk):
    process_area = get_object_or_404(ProcessGroup, pk=pk)
    if request.method == 'POST':
        form = ProcessGroupForm(
            request.POST, request.FILES, instance=process_area)
        if form.is_valid():
            process_group_update = form.save(commit=False)
            process_group_update.updated_by = request.user
            process_group_update.save()
            return redirect('document_list')
    else:
        form = ProcessGroupForm(instance=process_area)
    return render(request, 'base/master_process_group_update.html', {'form': form})


@login_required
@admin_user_required
def master_process_group_delete(request, pk):
    process_group = get_object_or_404(ProcessGroup, pk=pk)
    if request.method == 'POST':
        process_group.delete()
        return redirect('document_list')
    return render(request, 'base/master_process_group_confirm_delete.html', {'process_group': process_group})

# ---------------------------------------------------Process Area


@login_required
@admin_user_required
def master_process_area_form(request):
    if request.method == 'POST':
        form = ProcessAreaForm(request.POST, request.FILES)

        if form.is_valid():
            process_area_form = form.save(commit=False)
            process_area_form.created_by = request.user
            form.save()
            return redirect('master-process-area-list')
    else:
        form = ProcessAreaForm()
    return render(request, 'base/master_process_area_form.html', {'form': form})


@login_required
@admin_user_required
def master_process_area_list(request):
    documents = ProcessArea.objects.all()
    return render(request, 'base/master_process_area_list.html', {'documents': documents})


@login_required
@admin_user_required
def master_process_area_detail(request, pk):
    documents = get_object_or_404(ProcessArea, pk=pk)
    return render(request, 'base/master_process_area_detail.html', {'documents': documents})


@login_required
@admin_user_required
def master_process_area_update(request, pk):
    process_area = get_object_or_404(ProcessArea, pk=pk)
    if request.method == 'POST':
        form = ProcessAreaForm(
            request.POST, request.FILES, instance=process_area)
        if form.is_valid():
            process_area_update = form.save(commit=False)
            process_area_update.updated_by = request.user
            process_area_update.save()
            return redirect('master-process-area-list')
    else:
        form = ProcessAreaForm(instance=process_area)
    return render(request, 'base/master_process_area_update.html', {'form': form})


@login_required
@admin_user_required
def master_process_area_delete(request, pk):
    process_area = get_object_or_404(ProcessArea, pk=pk)
    if request.method == 'POST':
        process_area.delete()
        return redirect('master-process-area-list')
    return render(request, 'base/master_process_area_confirm_delete.html', {'process_area': process_area})

# ---------------------------------------------------------------------Role


@login_required
@admin_user_required
def master_role_form(request):
    if request.method == 'POST':
        form = RoleForm(request.POST, request.FILES)

        if form.is_valid():
            role_form = form.save(commit=False)
            role_form.created_by = request.user
            role_form.save()
            return redirect('document_list')
    else:
        form = RoleForm()
    return render(request, 'base/master_role_form.html', {'form': form})


@login_required
@admin_user_required
def master_role_list(request):
    documents = Role.objects.all()
    return render(request, 'base/master_role_list.html', {'documents': documents})


@login_required
@admin_user_required
def master_role_detail(request, pk):
    documents = get_object_or_404(Role, pk=pk)
    return render(request, 'base/master_role_detail.html', {'documents': documents})


@login_required
@admin_user_required
def master_role_update(request, pk):
    process_area = get_object_or_404(Role, pk=pk)
    if request.method == 'POST':
        form = RoleForm(request.POST, request.FILES, instance=process_area)
        if form.is_valid():
            role_update = form.save(commit=False)
            # role_update.admin_manager = request.user
            role_update.updated_by = request.user
            role_update.save()
            return redirect('document_list')
    else:
        form = RoleForm(instance=process_area)
    return render(request, 'base/master_role_update.html', {'form': form})


@login_required
@admin_user_required
def master_role_delete(request, pk):
    process_role = get_object_or_404(Role, pk=pk)
    if request.method == 'POST':
        process_role.delete()
        return redirect('document_list')
    return render(request, 'base/master_role_confirm_delete.html', {'process_role': process_role})


# -----------------HR Access Views--------------------------
# @login_required
# @hr_user_required
# def list_all_employees(request):
#     employees = CustomUser.objects.all()
#     return render(request, 'base/hr_access_list_all_employees.html', {'employees': employees})


# Pagination
def list_all_employees(request):
    employee_list = CustomUser.objects.all()
    paginator = Paginator(employee_list, 3)  # Show 3 employees per page

    page = request.GET.get('page')
    try:
        employees = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        employees = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        employees = paginator.page(paginator.num_pages)

    return render(request, 'base/hr_access_list_all_employees.html', {'employees': employees})


# def list_all_employees(request):
#     query = request.GET.get('q')
#     employee_list = CustomUser.objects.all()

#     if query:
#         employee_list = employee_list.filter(
#             Q(name__icontains=query) |
#             Q(username__icontains=query) |
#             Q(email__icontains=query) |
#             Q(employee_id__icontains=query) |
#             Q(department__icontains=query) |
#             Q(user_type__icontains=query) |
#             Q(phone_number__icontains=query)|
#             Q(user__icontains=query)
#         )
#     paginator = Paginator(employee_list, 3)  # Show 3 employees per page

#     page = request.GET.get('page')
#     try:
#         employees = paginator.page(page)
#     except PageNotAnInteger:
#         # If page is not an integer, deliver first page.
#         employees = paginator.page(1)
#     except EmptyPage:
#         # If page is out of range (e.g. 9999), deliver last page of results.
#         employees = paginator.page(paginator.num_pages)

#     return render(request, 'base/hr_access_list_all_employees.html', {'employees': employees})

@login_required
@hr_user_required
def create_employee(request):
    if request.method == 'POST':
        form = EmployeeCreationForm(request.POST)
        try:
            if form.is_valid():
                create_employees = form.save(commit=False)
                create_employees.created_by = request.user
                create_employees.save()
                messages.success(request, "Employee created successfully.")
                # Redirect to home after successful employee creation
                return redirect('home')
        except Exception as e:
            logger.exception("An error occurred while creating an employee:")
            messages.error(
                request, "An error occurred while creating an employee. Please try again.")
    else:
        form = EmployeeCreationForm()
    return render(request, 'base/create_employee.html', {'form': form, 'messages': messages.get_messages(request)})


@login_required
@hr_user_required
def edit_employee(request, pk):
    employee = get_object_or_404(CustomUser, pk=pk)
    if request.method == 'POST':
        form = EmployeeUpdateForm(request.POST, instance=employee)
        try:
            if form.is_valid():
                edit_employees = form.save(commit=False)
                edit_employees.updated_by = request.user
                edit_employees.save()
                messages.success(request, "Employee Edited successfully.")
                # return redirect('view_employee', pk=pk)
                return redirect('list-all-employees')
        except Exception as e:
            logger.exception("An error occurred while editing an employee:")
            messages.error(
                request, "An error occurred while editing an employee. Please try again.")
    else:
        form = EmployeeUpdateForm(instance=employee)
    return render(request, 'base/edit_employee.html', {'form': form, 'employee': employee})


@login_required
@hr_user_required
def delete_employee(request, pk):
    employee = get_object_or_404(CustomUser, pk=pk)
    if request.method == 'POST':
        employee.delete()
        return redirect('home')
    return render(request, 'base/delete_employee.html', {'employee': employee})


# ----------------Try V Model-------------------#

def try_model(request):
    all_process_groups = ProcessGroup.objects.all()
    process_group_name = request.GET.get('process_group_name')

    if process_group_name:
        aspice_docs = AspiceSdlcDoc.objects.filter(
            process_group__process_group_name=process_group_name)
    else:
        aspice_docs = AspiceSdlcDoc.objects.all()

    context = {'all_process_groups': all_process_groups,
               'aspice_docs': aspice_docs, 'process_group_name': process_group_name}
    return render(request, 'base/tlm_document_list.html', context)
