from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from django.contrib.auth import get_user_model
from .models import Profile

# Email Configuration
from django.core.mail import send_mail
from django.conf import settings

CustomUser = get_user_model()


@receiver(post_save, sender=CustomUser)
def create_profile(sender, instance, created, **kwargs):
    if created:
        user = instance
        Profile.objects.create(user=user,
                               username=user.username,
                               email=user.email,
                               phone_number=user.phone_number,
                               department=user.department,
                               position=user.position,
                               employee_id=user.employee_id
                               )

        send_mail(
            subject=' Welcome to Niyata-Process',
            message=''' f"Dear ,{user.username}!"
            Welcome to Niyata-Process! We are thrilled to have you join our community of innovative thinkers and problem solvers.

At Niyata-Process, we believe in empowering individuals like you to achieve their goals and make a difference. Whether you're here to streamline processes, enhance productivity, or drive innovation, we're here to support you every step of the way.

As a new member, you now have access to a wealth of resources, tools, and a vibrant community ready to collaborate and share insights. We encourage you to explore our platform, connect with other members, and make the most of your Niyata-Process experience.

If you have any questions or need assistance, please don't hesitate to reach out to us. We're here to help you succeed.

Once again, welcome to Niyata-Process. We are excited to embark on this journey with you!

Best regards,
The Niyata-Process Team''',
            from_email=settings.EMAIL_HOST_USER,
            recipient_list=[instance.email],
            fail_silently=False

        )


def updateUser(sender, instance, created, **kwargs):
    profile = instance
    user = profile.user

    if created == False:
        user.username = profile.username
        user.email = profile.email
        user.save()


def deleteUser(sender, instance, **kwargs):
    try:
        user = instance.user
        user.delete()
    except:
        pass


# Connect signal handlers
post_save.connect(create_profile, sender=CustomUser)
post_save.connect(updateUser, sender=Profile)
post_delete.connect(deleteUser, sender=Profile)
