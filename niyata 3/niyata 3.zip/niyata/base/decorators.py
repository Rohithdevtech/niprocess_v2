from functools import wraps
from django.core.exceptions import PermissionDenied

def normal_user_required(function):
    @wraps(function)
    def wrap(request, *args, **kwargs):
        if request.user.user_type != 'normal':
            raise PermissionDenied
        return function(request, *args, **kwargs)
    return wrap

def hr_user_required(function):
    @wraps(function)
    def wrap(request, *args, **kwargs):
        if request.user.user_type != 'hr':
            raise PermissionDenied
        return function(request, *args, **kwargs)
    return wrap


# def admin_user_required(function):
#     @wraps(function)
#     def wrap(request, *args, **kwargs):
#         if request.user.user_type != 'admin':
#             raise PermissionDenied
#         return function(request, *args, **kwargs)
#     return wrap

def admin_user_required(view_func):
    @wraps(view_func)
    def wrapped_view(request, *args, **kwargs):
        if request.user.user_type != 'admin':
            raise PermissionDenied
        return view_func(request, *args, **kwargs)
    return wrapped_view

def superuser_required(function):
    @wraps(function)
    def wrap(request, *args, **kwargs):
        if request.user.user_type != 'superuser':
            raise PermissionDenied
        return function(request, *args, **kwargs)
    return wrap
